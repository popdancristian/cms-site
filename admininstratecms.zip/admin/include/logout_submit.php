<?php
//--Iesire user
unset($_SESSION['a_user']);
header('Location: login.php');
?>